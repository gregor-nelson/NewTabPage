// main.js - Main orchestration
import { initClock, updateClockSettings } from './components/clock.js';
import { initCalendar, updateCalendarSettings } from './components/calendar.js';
import { initSettings, getSettings } from './components/settings.js';

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    // Initialize settings first, with callback for when settings change
    initSettings(handleSettingsChange);
});

function handleSettingsChange(settings) {
    // Update clock with new settings
    updateClockSettings({
        timeFormat: settings.timeFormat,
        showSeconds: settings.showSeconds
    });
    
    // Update calendar with new settings
    updateCalendarSettings({
        weekStartsOn: settings.weekStartsOn,
        showWeekNumbers: settings.showWeekNumbers
    });
}

// Initialize components after settings are loaded
setTimeout(() => {
    const settings = getSettings();
    
    initClock({
        timeFormat: settings.timeFormat,
        showSeconds: settings.showSeconds
    });
    
    initCalendar({
        weekStartsOn: settings.weekStartsOn,
        showWeekNumbers: settings.showWeekNumbers
    });
}, 100);
