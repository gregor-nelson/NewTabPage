// settings.js - Settings management
const DEFAULT_SETTINGS = {
    timeFormat: '24h',
    showSeconds: true,
    weekStartsOn: 'monday',
    showWeekNumbers: true
};

let currentSettings = { ...DEFAULT_SETTINGS };
let onSettingsChangeCallback = null;

export function initSettings(onChangeCallback) {
    onSettingsChangeCallback = onChangeCallback;
    
    // Set up modal controls
    setupModalControls();
    
    // Load settings from storage
    loadSettings();
    
    // Set up setting controls
    setupSettingControls();
}

function setupModalControls() {
    const settingsBtn = document.getElementById('settings-btn');
    const settingsModal = document.getElementById('settings-modal');
    const closeSettingsBtn = document.getElementById('close-settings');
    
    // Open modal
    settingsBtn?.addEventListener('click', () => {
        settingsModal?.classList.add('show');
    });
    
    // Close modal
    closeSettingsBtn?.addEventListener('click', closeModal);
    
    // Close on outside click
    settingsModal?.addEventListener('click', (e) => {
        if (e.target === settingsModal) {
            closeModal();
        }
    });
    
    // Close on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && settingsModal?.classList.contains('show')) {
            closeModal();
        }
    });
}

function closeModal() {
    const settingsModal = document.getElementById('settings-modal');
    settingsModal?.classList.remove('show');
}

function setupSettingControls() {
    // Time format toggle
    const timeFormatToggle = document.getElementById('time-format-toggle');
    timeFormatToggle?.addEventListener('change', (e) => {
        updateSetting('timeFormat', e.target.checked ? '24h' : '12h');
    });
    
    // Show seconds toggle
    const showSecondsToggle = document.getElementById('show-seconds-toggle');
    showSecondsToggle?.addEventListener('change', (e) => {
        updateSetting('showSeconds', e.target.checked);
    });
    
    // Week starts on select
    const weekStartSelect = document.getElementById('week-start-select');
    weekStartSelect?.addEventListener('change', (e) => {
        updateSetting('weekStartsOn', e.target.value);
    });
    
    // Show week numbers toggle
    const showWeekNumbersToggle = document.getElementById('show-week-numbers-toggle');
    showWeekNumbersToggle?.addEventListener('change', (e) => {
        updateSetting('showWeekNumbers', e.target.checked);
    });
}

function loadSettings() {
    // Try to load from chrome.storage
    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.sync.get(['newtabSettings'], (result) => {
            if (result.newtabSettings) {
                currentSettings = { ...DEFAULT_SETTINGS, ...result.newtabSettings };
            }
            applySettings();
        });
    } else {
        // Fallback to localStorage for testing
        const stored = localStorage.getItem('newtabSettings');
        if (stored) {
            try {
                currentSettings = { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
            } catch (e) {
                console.error('Error parsing settings:', e);
            }
        }
        applySettings();
    }
}

function applySettings() {
    // Update UI controls to match current settings
    const timeFormatToggle = document.getElementById('time-format-toggle');
    if (timeFormatToggle) {
        timeFormatToggle.checked = currentSettings.timeFormat === '24h';
    }
    
    const showSecondsToggle = document.getElementById('show-seconds-toggle');
    if (showSecondsToggle) {
        showSecondsToggle.checked = currentSettings.showSeconds;
    }
    
    const weekStartSelect = document.getElementById('week-start-select');
    if (weekStartSelect) {
        weekStartSelect.value = currentSettings.weekStartsOn;
    }
    
    const showWeekNumbersToggle = document.getElementById('show-week-numbers-toggle');
    if (showWeekNumbersToggle) {
        showWeekNumbersToggle.checked = currentSettings.showWeekNumbers;
    }
    
    // Notify components of settings
    if (onSettingsChangeCallback) {
        onSettingsChangeCallback(currentSettings);
    }
}

function updateSetting(key, value) {
    currentSettings[key] = value;
    saveSettings();
    
    // Notify components of change
    if (onSettingsChangeCallback) {
        onSettingsChangeCallback(currentSettings);
    }
}

function saveSettings() {
    // Save to chrome.storage
    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.sync.set({ newtabSettings: currentSettings });
    } else {
        // Fallback to localStorage for testing
        localStorage.setItem('newtabSettings', JSON.stringify(currentSettings));
    }
}

export function getSettings() {
    return { ...currentSettings };
}
